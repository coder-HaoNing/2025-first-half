package com.haoning.vo;

import static org.junit.Assert.assertEquals;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class TestDate {
	@BeforeClass
	public static void Beforeclass() throws Exception
	{
		System.out.println("所有测试用例开始执行");
	}
	@AfterClass
	public static void Afterclass() throws Exception
	{
		System.out.println("所有测试用例执行结束");
	}
	@Before
	public void Beforetest() throws Exception
	{
		System.out.println("执行单个测试用例");
	}
	@After
	public void Aftertest() throws Exception
	{
		System.out.println("结束单个测试用例");
		System.out.println();
	}
	@Test
	public void Test1()
	{
		System.out.println("当前为测试用例1");
		assertEquals("日期输入正确",Date.RightDate("19870101"));
	}
	@Test
	public void Test2()
	{
		System.out.println("当前为测试用例2");
		assertEquals("不符合规定->月份不合法",Date.RightDate("20211301"));
	}
	@Test
	public void Test3()
	{
		System.out.println("当前为测试用例3");
		assertEquals("不符合规定->月份不合法",Date.RightDate("20210015"));
	}
	@Test
	public void Test4()
	{
		System.out.println("当前为测试用例4");
		assertEquals("日期输入正确",Date.RightDate("20200229"));
	}
	@Test
	public void Test5()
	{
		System.out.println("当前为测试用例5");
		assertEquals("不符合规定->天数不合法",Date.RightDate("20210229"));
	}
	@Test
	public void Test6()
	{
		System.out.println("当前为测试用例6");
		assertEquals("不符合规定->格式错误",Date.RightDate("2021229"));
	}
	@Test
	public void Test7()
	{
		System.out.println("当前为测试用例7");
		assertEquals("不符合规定->年份不合法",Date.RightDate("19800101"));
	}
}
