package com.haoning.vo;

import static org.junit.Assert.assertEquals;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class TestDivision {
	@BeforeClass
	public static void Beforeclass() throws Exception
	{
		System.out.println("所有测试用例开始执行");
	}
	@AfterClass
	public static void Afterclass() throws Exception
	{
		System.out.println("所有测试用例执行结束");
	}
	@Before
	public void Beforetest() throws Exception
	{
		System.out.println("执行单个测试用例");
	}
	@After
	public void Aftertest() throws Exception
	{
		System.out.println("结束单个测试用例");
		System.out.println();
	}
	@Test
	public void Test1()
	{
		System.out.println("当前为测试用例1");
		assertEquals("2.0",Division.NewDivision("246,123"));
	}
	@Test
	public void Test2()
	{
		System.out.println("当前为测试用例2");
		assertEquals("5.2",Division.NewDivision("10.4,2"));
	}
	@Test
	public void Test3()
	{
		System.out.println("当前为测试用例3");
		assertEquals("非法输入->没有逗号",Division.NewDivision("12345"));
	}
	@Test
	public void Test4()
	{
		System.out.println("当前为测试用例4");
		assertEquals("非法输入->输入为非数字",Division.NewDivision("12a,34b"));
	}
	@Test
	public void Test5()
	{
		System.out.println("当前为测试用例5");
		assertEquals("非法输入->除数为0",Division.NewDivision("123,0"));
	}
}
