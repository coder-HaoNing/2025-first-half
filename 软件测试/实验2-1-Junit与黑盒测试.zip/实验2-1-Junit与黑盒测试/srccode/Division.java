package com.haoning.vo;

public class Division {
	public static String NewDivision(String innumber) {
		if (innumber.indexOf(',') < 0)
			return "非法输入->没有逗号";
		for (int i = 0; i < innumber.length(); i++) {
			if (innumber.charAt(i) == ',' || '0' <= innumber.charAt(i) && innumber.charAt(i) <= '9'
					|| innumber.charAt(i) == '.') {
				continue;
			}
			return "非法输入->输入为非数字";
		}
		String[] nlist = innumber.split(",");
		float number1 = Float.parseFloat(nlist[0]);
		float number2 = Float.parseFloat(nlist[1]);
		if (number2 == 0.0) {
			return "非法输入->除数为0";
		}
		float result = number1 / number2;
		return Float.toString(result);
	}
}
