package com.haoning.vo;
public class Date {
	public static String RightDate(String date) {
		if (date.length() != 8) {
			return "不符合规定->格式错误";
		}
		int year = Integer.parseInt(date.substring(0, 4));
		int month = Integer.parseInt(date.substring(4, 6));
		int day = Integer.parseInt(date.substring(6, 8));
		if (year > 2021 || year < 1987) {
			return "不符合规定->年份不合法";
		}
		if (month > 12 || month < 1) {
			return "不符合规定->月份不合法";
		}
		if ((year % 4 == 0 && year % 100 != 0) || year % 400 == 0) {
			int[] days = { 31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };
			if (day < 1 || day > days[month - 1]) {
				return "不符合规定->天数不合法";
			}
		} else {
			int[] days = { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };
			if (day < 1 || day > days[month - 1]) {
				return "不符合规定->天数不合法";
			}
		}
		return "日期输入正确";
	}
}
